from typing import Any, List, Dict, Optional
from .litellm_client import LiteLLMClient
import json

models = [
    "gemma-7b-it", # 0
    "gemma2-9b-it", # 1
    "llama-3.1-8b-instant", # 2
    "llama-3.1-70b-versatile", # 3
    "mixtral-8x7b-32768", # 4
    "llama3-groq-8b-8192-tool-use-preview", # 5
    "llama3-groq-70b-8192-tool-use-preview", # 6
    "llama3-8b-8192", # 7
    "llama3-70b-8192", # 8
]

SELECTED_MODEL = models[3]

class LitellmRouter:
    def __init__(self):
        self.default_api = "groq"  # Set default API as Groq
        self.apis = {
            "openai": LiteLLMClient(api="openai"),
            "groq": LiteLLMClient(api="groq"),
        }

    def perform_chat_completion(
        self,
        messages: List[Dict[str, str]],
        api_name: str = None,
        model: str = SELECTED_MODEL,
        **kwargs
    ) -> Any:
        api_to_use = api_name or self.default_api
        if api_to_use not in self.apis:
            raise ValueError(f"API '{api_to_use}' is not supported in LitellmRouter.")
        
        client = self.apis[api_to_use]
        return client.perform_completion(messages=messages, model=f"{api_to_use}/{model}", **kwargs)

    def summarize_text(self, text: str, summary_length: Optional[int] = 150) -> str:
        """
        Summarize the provided text.
        """
        messages = [
            {"role": "system", "content": "You are an expert summarizer."},
            {"role": "user", "content": f"Summarize the following text in {summary_length} words:\n\n{text}"}
        ]

        try:
            response = self.perform_chat_completion(
                messages=messages,
                model=SELECTED_MODEL,
                temperature=0.3,
                max_tokens=summary_length * 2,
                top_p=1,
                stop=None,
                stream=False
            )
            return response if isinstance(response, str) else str(response)
        except Exception as e:
            print(f"An error occurred during summarization: {e}")
            return f"Error during summarization: {str(e)}"

    def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        """
        Analyze the sentiment of the provided text.
        """
        messages = [
            {
                "role": "system",
                "content": "You are a data analyst API capable of sentiment analysis that responds in JSON. The JSON schema should include {\"sentiment_analysis\": {\"sentiment\": \"string (positive, negative, neutral)\", \"confidence_score\": \"number (0-1)\"}}."
            },
            {"role": "user", "content": text}
        ]

        response = self.perform_chat_completion(
            messages=messages,
            model=SELECTED_MODEL,
            temperature=0.0,
            max_tokens=100,
            top_p=1,
            stop=None,
            stream=False
        )

        try:
            sentiment_data = json.loads(response) if isinstance(response, str) else response
            return sentiment_data
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return {"error": "Failed to parse sentiment analysis result"}
        except Exception as e:
            print(f"An error occurred during sentiment analysis: {e}")
            return {"error": str(e)}

    def extract_task_requirements(self, text: str) -> Dict[str, Any]:
        """
        Extract tasks, requirements, and steps from the provided text.
        """
        messages = [
            {
                "role": "system",
                "content": "You are an expert task analyzer. Given an input, extract the main task, requirements, steps, and any additional components needed to achieve the objective. Provide a structured response in JSON format."
            },
            {"role": "user", "content": f"Analyze the following text and extract task information:\n\n{text}"}
        ]

        response = self.perform_chat_completion(
            messages=messages,
            model=SELECTED_MODEL,
            temperature=0.2,
            max_tokens=1000,
            top_p=1,
            stop=None,
            stream=False
        )

        try:
            task_data = json.loads(response) if isinstance(response, str) else response
            return task_data
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return {"error": "Failed to parse task analysis result"}
        except Exception as e:
            print(f"An error occurred during task analysis: {e}")
            return {"error": str(e)}