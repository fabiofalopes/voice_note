import os
from dotenv import load_dotenv
from litellm import completion
from typing import Any, Dict, List

# Load environment variables from .env file
load_dotenv()

# Get API keys from environment
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY is not set in .env file")

GROQ_API_KEY = os.getenv('GROQ_API_KEY')
# GROQ_API_KEY can be optional if not used
if not GROQ_API_KEY:
    raise ValueError("GROQ_API_KEY is not set in .env file")

# Set API keys in environment
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY
os.environ['GROQ_API_KEY'] = GROQ_API_KEY

class LiteLLMClient:
    def __init__(self, api: str = 'openai'):
        self.api = api.lower()
        if self.api not in ['openai', 'groq']:
            raise ValueError("Unsupported LLM API. Supported APIs: 'openai', 'groq'.")

    def perform_completion(self, messages: List[Dict[str, str]], model: str, **kwargs) -> Any:
        try:
            response = completion(model=model, messages=messages, api_base=self.api, **kwargs)
            return response['choices'][0]['message']['content'].strip()
        except Exception as e:
            print(f"An error occurred during LLM completion: {e}")
            return {"error": str(e)}