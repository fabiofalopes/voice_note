import argparse
import os
import sys

# Add the project root to the Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from stt_api_integrations.stt_router import SttAPIRouter
from litellm_api_integrations.litellm_router import LitellmRouter
from audio_processing.preprocess import preprocess_audio
from audio_processing.recorder import AudioRecorder

def main():
    parser = argparse.ArgumentParser(description="Record, transcribe, translate, and analyze audio files.")
    parser.add_argument('--record', action='store_true', help='Record audio instead of using an existing file')
    parser.add_argument('--duration', type=int, default=10, help='Duration of recording in seconds (ignored if --record-until-q is used)')
    parser.add_argument('--record-until-q', action='store_true', help='Record audio until Ctrl+C is pressed')
    parser.add_argument('--list-devices', action='store_true', help='List available input devices')
    parser.add_argument('--input-device', type=int, help='Input device index to use for recording')
    parser.add_argument('--prompt', type=str, help='Prompt for transcription')
    parser.add_argument('--language', type=str, help='Language of the audio')
    parser.add_argument('--temperature', type=float, help='Temperature for transcription')
    parser.add_argument('--output', type=str, help='Path to save the transcription output')
    parser.add_argument('--list-speech-models', action='store_true', help='List available speech models')
    parser.add_argument('--list-llm-models', action='store_true', help='List available LLM models')
    parser.add_argument('--transcribe', action='store_true', help='Transcribe the audio')
    parser.add_argument('--translate', action='store_true', help='Translate the audio')
    parser.add_argument('--api', type=str, default='groq', help='Specify the API to use for speech')
    parser.add_argument('--model', type=str, help='Model ID for transcription, translation, or LLM tasks')
    parser.add_argument('file_path', type=str, nargs='?', help='Path to save the audio file or existing audio file.')

    args = parser.parse_args()

    recorder = AudioRecorder()

    if args.list_devices:
        recorder.list_input_devices()
        return

    if args.file_path is None and not args.list_devices:
        parser.error("file_path is required unless --list-devices is used")

    if args.record or args.record_until_q:
        try:
            if args.record_until_q:
                input_file = recorder.record_until_q(os.path.basename(args.file_path), args.input_device)
            else:
                input_file = recorder.record(args.duration, os.path.basename(args.file_path), args.input_device)
        except Exception as e:
            print(f"An error occurred during recording: {e}")
            return
    else:
        input_file = args.file_path

    preprocessed_file = "preprocessed_" + os.path.basename(input_file)

    # Preprocess the audio file
    success = preprocess_audio(input_file, preprocessed_file)
    if not success:
        print("Audio preprocessing failed.")
        return

    stt_router = SttAPIRouter()
    litellm_router = LitellmRouter()

    if args.list_speech_models:
        available_models = stt_router.list_available_models()
        for api, models in available_models.items():
            print(f"{api.capitalize()} Speech Models:")
            for model in models:
                print(f"  - {model}")
        return

    if args.list_llm_models:
        print("LLM Models:")
        for api, api_client in litellm_router.apis.items():
            if hasattr(api_client, 'models'):
                print(f"{api.capitalize()} Models:")
                for model in api_client.models:
                    print(f"  - {model}")
        return

    result = {}

    if args.transcribe:
        transcription = stt_router.transcribe_audio(
            preprocessed_file,
            api_name=args.api,
            model_id=args.model,
            prompt=args.prompt,
            language=args.language,
            temperature=args.temperature
        )
        result["transcription"] = transcription

    if args.translate:
        translation = stt_router.translate_audio(
            preprocessed_file,
            api_name=args.api,
            model_id=args.model,
            prompt=args.prompt,
            language=args.language,
            temperature=args.temperature
        )
        result["translation"] = translation

    # Handle post-processing
    if args.transcribe:
        text = result["transcription"].get("text", "") if isinstance(result.get("transcription"), dict) else result.get("transcription", "")
        if text:
            try:
                summary = litellm_router.summarize_text(text)
                sentiment = litellm_router.analyze_sentiment(text)
                task_analysis = litellm_router.extract_task_requirements(text)
                result.update({
                    "summary": summary,
                    "sentiment_analysis": sentiment,
                    "task_analysis": task_analysis
                })
            except Exception as e:
                print(f"An error occurred during post-processing: {e}")
                result.update({
                    "post_processing_error": str(e)
                })

    # Handle output
    if result:
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(result, f, indent=2)
            print(f"Results saved to {args.output}")

        for key, value in result.items():
            print("----------------------------------------")
            print(f"**{key.replace('_', ' ').capitalize()}:**")
            print(json.dumps(value, indent=2))
        print("----------------------------------------")
    else:
        print("No operation performed. Use --transcribe or --translate.")

    # Clean up preprocessed file
    os.remove(preprocessed_file)

    if args.api == 'local' and 'local' not in stt_router.apis:
        print("Error: Local API is not available. Make sure whisper is installed.")
        return

if __name__ == "__main__":
    main()