import os
from typing import Optional, Union, List, Dict, Any
import whisper
import traceback

class LocalWhisperAPI:
    models = ["tiny", "base", "small", "medium", "large"]
    SELECTED_MODEL = "base"

    def __init__(self):
        self.model = None

    def transcribe_audio(
        self,
        file_path: str,
        model_id: Optional[str] = None,
        prompt: Optional[str] = None,
        response_format: str = 'json',
        language: Optional[str] = None,
        temperature: Optional[float] = None,
        timestamp_granularities: Optional[List[str]] = None
    ) -> Union[Dict[str, Any], str]:
        try:
            model_id = model_id or self.SELECTED_MODEL
            if self.model is None or self.model.name != model_id:
                self.model = whisper.load_model(model_id)

            result = self.model.transcribe(
                file_path,
                language=language,
                temperature=temperature
            )

            full_transcription = result["text"]
            return full_transcription if response_format != 'json' else {"text": full_transcription}

        except Exception as e:
            print(f"An error occurred during transcription: {e}")
            traceback.print_exc()
            return {"error": str(e)}

    def translate_audio(
        self,
        file_path: str,
        model_id: Optional[str] = None,
        prompt: Optional[str] = None,
        response_format: str = 'json',
        language: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Union[Dict[str, Any], str]:
        try:
            model_id = model_id or self.SELECTED_MODEL
            if self.model is None or self.model.name != model_id:
                self.model = whisper.load_model(model_id)

            result = self.model.transcribe(
                file_path,
                task="translate",
                language=language,
                temperature=temperature
            )

            translation = result["text"]
            return translation if response_format != 'json' else {"text": translation}

        except Exception as e:
            print(f"An error occurred during translation: {e}")
            traceback.print_exc()
            return {"error": str(e)}
