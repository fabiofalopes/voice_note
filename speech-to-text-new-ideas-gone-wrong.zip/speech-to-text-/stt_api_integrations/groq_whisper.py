import os
from typing import Optional, Union, List, Dict, Any
from groq import Groq
from config.config import GROQ_API_KEY
import traceback
from pydub import AudioSegment

class GroqWhisperAPI:
    models = [
        "whisper-large-v3",
        "distil-whisper-large-v3-en"
    ]

    SELECTED_MODEL = models[0]

    def __init__(self):
        self.selected_model = self.models[0]
        if not GROQ_API_KEY:
            raise ValueError("GROQ_API_KEY is not set in environment variables.")
        os.environ['GROQ_API_KEY'] = GROQ_API_KEY
        self.client = Groq()

    def transcribe_audio(
        self,
        file_path: str,
        model_id: Optional[str] = None,
        prompt: Optional[str] = None,
        response_format: str = 'json',
        language: Optional[str] = None,
        temperature: Optional[float] = None,
        timestamp_granularities: Optional[List[str]] = None
    ) -> Union[Dict[str, Any], str]:
        try:
            model_id = model_id or self.SELECTED_MODEL
            file_size = os.path.getsize(file_path)
            if file_size > 25 * 1024 * 1024:  # 25 MB
                chunks = self.split_audio(file_path)
                transcriptions = []
                for chunk in chunks:
                    with open(chunk, "rb") as file:
                        transcription = self.client.audio.transcriptions.create(
                            file=(os.path.basename(chunk), file.read()),
                            model=model_id,
                            prompt=prompt,
                            response_format=response_format,
                            language=language,
                            temperature=temperature,
                            timestamp_granularities=timestamp_granularities
                        )
                    transcriptions.append(transcription.text if response_format != 'json' else transcription.to_dict()['text'])
                full_transcription = " ".join(transcriptions)
            else:
                with open(file_path, "rb") as file:
                    transcription = self.client.audio.transcriptions.create(
                        file=(os.path.basename(file_path), file.read()),
                        model=model_id,
                        prompt=prompt,
                        response_format=response_format,
                        language=language,
                        temperature=temperature,
                        timestamp_granularities=timestamp_granularities
                    )
                full_transcription = transcription.text if response_format != 'json' else transcription.to_dict()['text']

            return full_transcription if response_format != 'json' else {"text": full_transcription}

        except Exception as e:
            print(f"An error occurred during transcription: {e}")
            traceback.print_exc()
            return {"error": str(e)}

    def translate_audio(
        self,
        file_path: str,
        model_id: Optional[str] = None,
        prompt: Optional[str] = None,
        response_format: str = 'json',
        language: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Union[Dict[str, Any], str]:
        try:
            model_id = model_id or self.SELECTED_MODEL
            with open(file_path, "rb") as file:
                translation = self.client.audio.translations.create(
                    file=(os.path.basename(file_path), file.read()),
                    model=model_id,
                    prompt=prompt,
                    response_format=response_format,
                    language=language,
                    temperature=temperature
                )
            return translation.to_dict() if response_format == 'json' else translation.text

        except Exception as e:
            print(f"An error occurred during translation: {e}")
            traceback.print_exc()
            return {"error": str(e)}

    @staticmethod
    def split_audio(file_path: str) -> List[str]:
        audio = AudioSegment.from_file(file_path)
        # Calculate chunk length based on size constraints
        # This is a simplistic approach and may need refinement
        chunk_length_ms = 60000  # 1 minute chunks
        chunks = []
        for i in range(0, len(audio), chunk_length_ms):
            chunk = audio[i:i + chunk_length_ms]
            chunk_path = f"chunk_{i//chunk_length_ms}.wav"
            chunk.export(chunk_path, format="wav")
            chunks.append(chunk_path)
        return chunks