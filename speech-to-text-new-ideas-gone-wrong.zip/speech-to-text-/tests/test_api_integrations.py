import os
import sys
import unittest
from unittest.mock import patch, MagicMock, mock_open
import os

# Add the project root directory to the Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)

from stt_api_integrations.groq_whisper import GroqWhisperAPI
from litellm import completion

class TestGroqWhisperAPI(unittest.TestCase):
    @patch('stt_api_integrations.groq_whisper.Groq')
    def test_transcribe_audio_success(self, mock_groq):
        mock_client = MagicMock()
        mock_groq.return_value = mock_client
        mock_transcription = MagicMock()
        mock_transcription.to_dict.return_value = {'text': 'Transcription successful.'}
        mock_client.audio.transcriptions.create.return_value = mock_transcription

        api = GroqWhisperAPI()
        test_file_path = "inputs/UsingOllamatoRunLocalLLMsontheRaspberryPi5.mp3"

        with patch('builtins.open', mock_open(read_data=b'dummy audio content')):
            with patch('os.path.getsize', return_value=1000):  # Mock file size
                result = api.transcribe_audio(
                    file_path=test_file_path,
                    model_id="whisper-large-v3",
                    prompt="Test prompt",
                    response_format="json",
                    language="en",
                    temperature=0.0
                )

        self.assertEqual(result, {"text": "Transcription successful."})
        mock_client.audio.transcriptions.create.assert_called_once()

    @patch('stt_api_integrations.groq_whisper.Groq')
    def test_translate_audio_success(self, mock_groq):
        mock_client = MagicMock()
        mock_groq.return_value = mock_client
        mock_translation = MagicMock()
        mock_translation.to_dict.return_value = {'text': 'Translation successful.'}
        mock_client.audio.translations.create.return_value = mock_translation

        api = GroqWhisperAPI()
        test_file_path = "inputs/UsingOllamatoRunLocalLLMsontheRaspberryPi5.mp3"

        with patch('builtins.open', mock_open(read_data=b'dummy audio content')):
            result = api.translate_audio(
                file_path=test_file_path,
                model_id="whisper-large-v3",
                prompt="Test prompt",
                response_format="json",
                language="en",
                temperature=0.0
            )

        self.assertEqual(result, {'text': 'Translation successful.'})
        mock_client.audio.translations.create.assert_called_once()

class TestLiteLLMCompletion(unittest.TestCase):
    @patch('litellm.completion')
    def test_perform_completion_success_groq(self, mock_completion):
        mock_response = {
            'choices': [
                {'message': {'content': "Here's a joke about a bicycle."}}
            ]
        }
        mock_completion.return_value = mock_response

        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Tell me a joke."}
        ]
        model = "groq/llama3-8b-8192"

        result = completion(model=model, messages=messages)

        # Check if the result contains a joke about a bicycle
        self.assertIn('bicycle', result['choices'][0]['message']['content'].lower())
        mock_completion.assert_called_once_with(model=model, messages=messages)

    @patch('litellm.completion')
    def test_perform_completion_failure(self, mock_completion):
        mock_completion.side_effect = Exception("API Error")

        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Tell me a joke."}
        ]
        model = "groq/llama3-8b-8192"

        try:
            completion(model=model, messages=messages)
            self.fail("Expected an exception to be raised")
        except Exception as e:
            self.assertIn("API Error", str(e))

        mock_completion.assert_called_once_with(model=model, messages=messages)